void configureFontAssets() {}
