# Development log

## 2026-10-17 — Execution recovery

- Read new master directive; it supersedes historical phase approval stops and authorizes local remediation and bounded independent agents.
- Inspected Git, sources, tests and Phase 0–0.3 reports/evidence. Branch `master`, two commits; large user-staged foundation/results, mixed worktree changes and untracked final Phase 0.3 artifacts preserved. No Git writes.
- Independent repository/rendering agents confirmed production editor/document/commands/storage are absent; main remains starter, benchmark_main owns lab. Stale widget issue is already fixed. Geometry/index deltas are reusable and cheap; whole-tile invalidation/raster reconstruction remains dominant.
- Reconciled all 243 original backlog tasks plus three explicit remediation subtasks (246 total), permanent instructions/source directive and required management documents. Historical verification is labeled separately; no new benchmark claim.
- Existing `.gitignore` already excludes build/.dart_tool/coverage/logs. No broad generated-artifact policy changes required. Preserve small evidence and bound new raw output.
- Flutter sandbox attempted SDK stamp refresh and was denied; requested narrowly scoped execution approval without upgrades. SDK version confirmed 3.41.9 / Dart 3.11.5. Toolchain discovery and new baseline checks in progress.
- Chosen next experiment: dirty-region repair, not smaller/paced tiles or a geometry/index rewrite. No package, platform, state-management or product-scope change.

- Fresh baseline analysis clean, 53 host tests pass; current toolchain doctor confirms macOS/Chrome, Xcode 26.2, Android licenses partly unaccepted and no connected mobile device. After opt-in prototype edits, analysis and all 16 existing tile/recovery tests pass. Raw logs are ignored; compact verification JSON is retained.

- Dirty repair implemented behind `WB_DIRTY_REPAIR` plus existing cache/recovery flags. Retains clean base pixels, bounds/merges damage, replays affected entries once and pins one cloned image during async repair. Whole-image output allocation remains; no native benefit inferred.
- Independent agent added seven regression tests; root added controlled repair failure/retry coverage. Initial seven host tests passed, but Chrome found stale old pixels/double alpha in combined exclusion-path composition (59/60 pass). Warm baseline matched, proving a new repair defect. Iterative rectangular difference clips resolved it without relaxing assertions. All eight focused Chrome and full **61 host + 61 Chrome** pass; final analysis clean. Native engine defect is not inferred.
- Compiler ENOSPC interrupted two test attempts; removed only ignored project compiler/native outputs (about 1 GiB). External available capacity later recovered to 3.2 GiB, enabling all checks. Failure logs and compact results retained.
- Current same-source matched Chrome profile reference/candidate diagnostics are underway, three realistic editing workloads only; no full gate claim. User Git index hash is unchanged.

- Matched final-source profile pairs completed on Chrome and macOS: three six-second edit cases each variant, 12 windows total, all received samples retained, no reported viewport/lifecycle changes or cache errors. Summaries strictly validate equivalent configurations and actual repair use. Native window raised/visually checked before both collections; focus telemetry unavailable and continuous occlusion unverified.
- Repair improves normal/single edits but Chrome dense still fails, native multi regresses and native image-await remains costly. Rejected promotion/full qualification sweep, preserved failed gates and selected WB-0119 ordered retained-content/transient feasibility (ADR-005). This experimental stopping-rule update does not weaken the product gate. No new cold/navigation/long-soak claims.
- Independent plan audit verified all original IDs and no cycles; fixed gate prerequisites, renderer integration dependency and independent design/font/storage research readiness. Current 22/249 verified (8.84%); production milestones remain unchecked. Disk again ~240 MiB after collection, limiting further compiler work despite project-only cleanup.

Files changed in this session:

- `AGENTS.md`: concise project/resume/quality/delegation/authorization instructions.
- `docs/EXECUTION_DIRECTIVE.md`: verbatim durable source directive.
- `docs/MASTER_PLAN.md`: original 243 tasks plus six evidence-driven remediation tasks; dependencies, acceptance, tests/status/evidence.
- `docs/PROJECT_STATUS.md`: current checked-task progress, failures, coverage and next work.
- `docs/ARCHITECTURE.md`: actual lab ownership/boundaries and limited next experiment.
- `docs/DECISIONS.md`: autonomous execution, dirty repair, Chrome fix and measured stopping/retention alternatives.
- `docs/RISKS.md`: measured failures, resource/platform/storage and staged-work risks.
- `docs/TEST_MATRIX.md`: actual 61/61 coverage, commands and pending platform/input/reliability gates.
- `docs/PERFORMANCE.md`: historical links, unchanged budgets and executed per-target diagnostic results/limits.
- `docs/DEVELOPMENT_LOG.md`: concise audit/failure/fix/verification/file record.
- `docs/HANDOFF.md`: immediate safe resume and exact next actions.
- `docs/RELEASE_CHECKLIST.md`: mandatory unchecked V1 release gates.
- `README.md`: management links and reproducible opt-in profile diagnostics; historical sections preserved.
- `lib/src/benchmarks/scene_tile_cache.dart`: conservative bounded damage, clean-image reuse, clipped live regions, stale-safe pinned async repair, resource/error telemetry.
- `lib/src/benchmarks/scene_renderer.dart`: source-order dirty replay and retained base reconstruction, optional repair flag and replay counters.
- `lib/src/benchmarks/benchmark_page.dart`: opt-in flag propagated to sessions/disposal diagnostics and reports.
- `test/dirty_tile_repair_test.dart`: eight pixel/order/RTL/large-world/replay/race/budget/disposal/failure/fallback regressions.
- `tool/summarize_dirty_repair.py`: reuse existing summarizer with strict bounded matched-profile validation and explicit no-qualification output.
- `benchmark_results/execution-01/`: small raw paired captures, summaries, provenance/verification/recovery evidence; ignored raw text logs retained locally. Previous staged/working files left as found.

No SDK/package upgrades, Android/iOS/platform configuration, migrations, staging/commits or public release actions. Manual future checks: actual input/presentation, broader DPR/asset/device coverage, long-memory pressure and lifecycle; none counted as performed.

## 2026-10-18 — Retained-range experiment resumed

- Recovered safely after an intentional interruption. No profile collector/server was started before interruption. Analysis and 13 affected existing host regressions had passed; the agent-produced nine-test file was complete but unexecuted. User index checkpoint preserved in execution-02.
- Implemented default-off vector range retention, exact visible membership checks, explicit active elements in source order, bounded picture estimates/LRU, conservative invalidation and local origins. No new dependency, architecture adoption or platform/SDK changes.
- Nine focused host tests and then all 70 host/70 Chrome tests passed. Independent read-only review found an unused overview raster in later diagnostics; guarded diagnostic/manual preparation and added retained-disposal telemetry. Full regressions rerunning after those guards.
- Added strict direct/retained bounded validator reusing existing summary logic and wrote ADR-006 before profiling. No performance claim yet. Free disk recovered to about 3.4 GiB at resume; continue sequential builds.


### Execution 02 completion checkpoint

- Final vector correctness: nine retained graphics cases, all 70 host/70 Chrome before independent document additions; unused overview preparation guarded in diagnostics/manual move. Record clocks include first cache rebuild, but stop at CPU paint completion rather than physical readiness. Final benchmark source hashes match both per-target profile pairs.
- Profile direct/vector pairs collected serially on Chrome and macOS, three six-second rows per arm. Chrome dense recording P95 31.3→0.4 / 31.2→0.8 ms while stage stays34.6/32.3 ms. Native dense stage15.263/15.254 ms at narrower density, normal regresses6.136 ms. All received samples/commits/control fields preserved. Per-target summaries and PERFORMANCE contain P50/P95/P99, first-use clocks, visible counts, estimated picture bytes and short native RSS. No gate/physical/full-suite/long-memory claim.
- First native capture used the incorrect delay flag and was excluded. Correct pair used PHASE01_AUTORUN_DELAY_MS=20000, with AX Raise/sparse screenshots before suite. Corrected build initially hit ENOSPC, retry interrupted, later completed. Never substituted the uncontrolled capture as baseline.
- Read-only audit: swap allocated6GiB, compressor physical~6.36GiB, no snapshots; project growth cannot explain capacity swings. Only ignored old compiler hashes (~194MiB) removed after build ENOSPC. After disk reached zero during handoff, removed ignored test cache plus superseded incorrect-delay native compiler cache (~202MiB). Source, profile artifacts/evidence and index retained; no user apps/data/system VM changed. External recovery to8GiB not attributed; ~348MiB after cleanup, then~118MiB at final validation.
- Independent pure-Dart document models added, reviewed and corrected for missing per-element revision/opacity plus safe integer revision range. Models contain all13 logical variants, source-relative sibling order/derived preorder, immutable snapshots and iterative ownership validation. Partial WB-0201 stays unchecked for document metadata/settings/resource manifests.
- DocumentGeometry added after profiles: one O(n) snapshot world/inverse pass, O(1) point lookups, contextual missing-ID/numeric errors. Root reviewed source/tests; no Flutter/benchmark imports or renderer integration. Nine tests include200 seeded affine routes, ±1e9 tolerance and5,000 owners.
- Final **90 host +90 Chrome tests passed**, analysis clean. Additional retained-config model/page14/14 per target, focused geometry9host; no inflated unique-case count. Six malformed collector fixtures rejected, script syntax verified. Chrome pressure observation resolved when original suite completed90 before any guarded stop matched; no test terminated/retried. Default Python external-cache write denied; redirected temporary bytecode cache successfully.
- Final index SHA matches initial execution02 checkpoint, rendering sources still match built artifacts; no staging/commits/packages/SDK/platform edits. No local server listener at cleanup; own collectors/tests finished. No background execution.
- WB-0202/0203/0204/0210 verified: **26/249=10.44%**. WB-0119 remains IN_PROGRESS for actual layer reuse; WB-0114 unresolved. ADR-007 rejects vector promotion and reassesses layer footprint/engine-memory constraints, preserving all product targets.

Files created/modified in Execution 02 (earlier Execution 01/pre-existing changes remain separate):

- `lib/src/benchmarks/scene_picture_cache.dart` (new): bounded ordered vector retention, active/live ranges, local origins, membership/delta invalidation, fallback, estimates/ownership counters.
- `lib/src/benchmarks/scene_renderer.dart`: opt-in cache owner/record/sync/paint/dispose integration; source-order direct fallback.
- `lib/src/benchmarks/benchmark_page.dart`: experimental flags, equivalent direct/reference setup, actual active IDs, first-use reset/reporting and overview/disposal guards.
- `lib/src/benchmarks/benchmark_telemetry.dart`: command-to-first-paint-record proxy with explicit reset.
- `test/retained_ranges_test.dart` (new): nine fidelity/order/camera/mutation/overflow/budget/disposal regressions.
- `tool/summarize_retained_ranges.py` (new): strict matched profile/control/actual-edit/budget validation, always unqualified output.
- `lib/src/document/element.dart` (new): opaque IDs, immutable typed content/style, explicit safe revisions and opacity.
- `lib/src/document/document.dart` (new): immutable version/revision/order snapshot, lookup/children/preorder and structural validation.
- `lib/src/document/document_geometry.dart` (new): snapshot world/inverse transform resolution and contextual mapping errors.
- `test/document_model_test.dart` (new): eleven model/invariant/boundary cases.
- `test/document_geometry_test.dart` (new): nine transform/property/numerical/deep-hierarchy cases.
- `README.md`: reproducible retained experiment flags, collectors/validators and limits.
- `docs/MASTER_PLAN.md`: evidence/status for four verified independent tasks; parent vector/layer experiment and complete document contract remain unchecked.
- `docs/ARCHITECTURE.md`: implemented model/cache/transform ownership and missing integration boundaries.
- `docs/DECISIONS.md`: ADR-006 measurement contract; ADR-007 rejection/layer reassessment; ADR-008 production contract choices.
- `docs/PROJECT_STATUS.md`:26/249 verified progress, executed90/90 checks, measured failures, coverage and environment.
- `docs/PERFORMANCE.md`: both bounded direct/vector distributions, first-use clocks, actual densities/resource estimates and limits/exclusions.
- `docs/TEST_MATRIX.md`: actual90/90 coverage, retained-config checks, malformed collector/syntax checks and pending gates.
- `docs/RISKS.md`: current raster/layer exposure, memory/disk pressure, immutable snapshot and integration/platform risks.
- `docs/HANDOFF.md`: exact safe resume actions, current evidence/capacity and unfinished work.
- `docs/DEVELOPMENT_LOG.md`: this execution/failure/fix/verification/file record.
- `benchmark_results/execution-02/` (new): paired raw reports/environment/summaries, excluded capture, source/binary/index provenance, pressure/cleanup/collector-validation/verification JSON. Raw text logs are ignored; no large traces added.

No migration, package, Android/iOS or other platform configuration changes. No user command needed to migrate. Manual qualification still required later: real mouse/trackpad/touch/IME and presentation, varied DPR/assets, device/platform/lifecycle and long-memory stress. These are not counted as performed. Next work is in HANDOFF; no phase approval required.

## 2026-10-18 — Execution03 retained layers and complete document declarations

Implemented actual framework-composited static runs around live edits, default off. Layer handles exclusively own subtrees; PictureLayer owns pictures. Preflight caps/order/fallback, exact camera/membership, camera-relative recording, active/inactive delta behavior and disposal preserve existing scene/index. Graphics suite exposed a real fractional/DPR viewport double-clip defect; fixed with inflated hard recording clip plus one exact AA outer clip without weakening assertions. Added recording-failure cleanup/retry coverage. Pure document values now include deterministic settings/title/workspace/resource/UTC metadata with explicit unresolved legacy compatibility.

Verification:109 host +109 Chrome tests/16 files per target passed in fresh sequential per-file compiler processes, source hashes unchanged. Subsequent benchmark-only interleaved/report/page lookup changes pass3 configured page cases per target. Braces-only test lint corrected; final analysis clean. Initial all-in-one/first-batch ENOSPC and initial lint failure preserved as failures. Eight malformed collector/control fixtures rejected; independent review verified source hashes, counts, metrics, caps, matching density and exclusions. WB-0201 verified;27/249=10.84%. WB-0119/0114 remain unchecked.

User explicitly authorized assistant to reclaim space. Removed ignored project compiler caches523MiB, then verified inactive Gradle8.14.3 transforms (actual free gain5.749GiB). Other work regenerated2.649GiB there; writer not identified, so did not repeatedly delete it. Removed independently verified inactive8.12/9.2.0 transforms, gain1.765GiB. Downloaded modules/SDK/current-active caches/other project outputs/user data preserved; no apps/daemons stopped. Capacity remains volatile; all tests/builds/collectors serial. No package/version/config/migration changes.

Profile from frozen same sources: Chrome four six-second direct/vector/layer rows; actual dense visible5,638. Layer stage P95 dense single/prefix25.6/25.2ms versus direct32.5/32.5, still above16.7. Native actual dense visible2,764: three validated dense-only rows, layer3.965/5.057ms versus direct15.172/15.16. Native first baseline had two lifecycle changes; repeat normal had one, so full four-row validation rejected and normal excluded from every arm. No further retry or hidden control waiver. Interleaved16 edits trigger unchanged exposure cap and full direct fallback on both targets. Lifetime subtree builds/submissions2 and reuse demonstrate retention; reported engine cache bytes0 do not prove GPU raster caching. First-use recording/RSS clocks are not cold readiness/soak/physical presentation. Full distributions and exact limitations in PERFORMANCE. Defaults remain off; no full-gate pass.

ADR-011 reassesses after insufficient Chrome vector/layer strategies. Next investigate installed WebAssembly/backend behavior with explicit runtime/isolation evidence and CanvasKit/Safari fallback; no SDK upgrade or performance assumption. Installed help confirms --wasm support, but no Wasm build/runtime test executed. Current binaries remain synthetic diagnostics.

Files created/modified in this execution (pre-existing unrelated work preserved):
- `lib/src/benchmarks/scene_layer_cache.dart` (new): bounded ordered layer ownership/retention/fallback/accounting.
- `lib/src/benchmarks/scene_renderer.dart`: layer recording/invalidation/statistics/disposal and opt-in creation.
- `lib/src/benchmarks/benchmark_canvas.dart`: composited render box; shared direct-paint/query/selection helpers and listener lifecycle.
- `lib/src/benchmarks/benchmark_page.dart`: default-off layer/interleaved flags, canvas integration and matched diagnostic metadata/active paint indices.
- `lib/src/document/document.dart`: compatible versioned settings/title/workspace/resource/metadata snapshot validation.
- `lib/src/document/document_settings.dart` (new): pure canvas/grid/asset/font/UTC metadata values and boundaries.
- `test/retained_layers_test.dart` (new):10 graphics/ownership/error tests including strict actual pixels/subtree submissions.
- `test/document_settings_test.dart` (new):9 document declaration/default/validation tests.
- `test/benchmark_page_test.dart`: existing drag/cancel/pan/zoom/disposal cases inspect either canvas widget, allowing actual layer configuration.
- `tool/run_test_batches.py` (new): fresh sequential per-file compilers, explicit success/hash manifest under capacity pressure.
- `tool/summarize_layers.py` (new): strict controlled comparisons and explicitly partial dense-only native reporting.
- `README.md`: flags, ownership limits, collectors/validators and native exclusions.
- `docs/MASTER_PLAN.md`: WB-0201 verified and WB-0119 remaining scope/evidence updated.
- `docs/ARCHITECTURE.md`: implemented layer/value boundaries and unqualified integration limits.
- `docs/DECISIONS.md`: ADR-009/010 implementation contracts and ADR-011 measured reassessment.
- `docs/PROJECT_STATUS.md`:27/249 progress, actual checks/results and remaining risks.
- `docs/PERFORMANCE.md`: profile distributions/actual densities/controls/exclusions/first-use/resource limits.
- `docs/TEST_MATRIX.md`: executed109/109, configured page coverage and batching protocol.
- `docs/RISKS.md`: current raster/fragmentation/capacity/control/platform risks.
- `docs/HANDOFF.md`: exact resume actions and checkpoint state.
- `docs/DEVELOPMENT_LOG.md`: this record.
- `benchmark_results/execution-03/` (new): raw reports, strict summaries, lifecycle exclusion, source/binary/index provenance, small source snapshot, test/control/cleanup audits and verification. No large traces. Raw text logs/builds stay ignored.

No user migration/configuration commands required. Manual qualification still pending: actual mouse/trackpad/touch/IME/input-to-photon, large/varied assets/DPR, cold/navigation/all-visible/image-heavy and long-memory/platform/device/release checks. No background work after checkpoint.

Final checkpoint:9 Dart files formatted with0 changes; Python syntax/diff check/source archive/profile source hashes/task IDs valid. Cached Git index preserved. Approximately2.34GiB free; owned collectors/server/native app absent. `execution-03/final-checkpoint.json` records exact checks.

## 2026-10-18 — Execution04 web backend observability and rejection

Implemented compiler metadata and opt-in post-timing engine/thread/resource/header/worker evidence, using inspected installed3.41.9 loader/export state. Added loopback-only optional-isolation server and strict independent3-arm validator. Kept rendering/model/cache logic, SDK/packages/platform/production web files unchanged. Three host +three Chrome page cases and analysis pass. Complete109/109 regression remains execution03 historical evidence, not rerun without a rendering change.

Actual same-source Profile vector arms, four6s rows each: CanvasKit dense single/prefix/interleaved P9525.009/24.785/24.995ms; skwasm single29.3/29.2/31.201; actual multi38.275/33.155/32.335. All12 row controls/IDs/indices/density/assets match; complete frame/commit distributions recomputed.12 malformed backend/compiler/thread/resource/header/sample/quantile/density/lifecycle/commit/budget fixtures rejected. Independent audit confirmed metrics and a provenance gap: actual CanvasKit chromium engine files were initially not hashed; correct hashes added post-capture with explicit SDK/current-copy agreement. Skwasm app/engine binaries match single/multi, generated bootstrap hashes differ. No isolated compiler/thread causal or full-gate claim. No backend promotion; budgets/defaults unchanged.

Wasm graphics3 suites fail before loading0 cases. Pure geometry diagnostic also stalls at loading, interrupted after608s using exact owned command/stdout proof; exit0+'No tests ran' is explicitly STOPPED, not PASS. No SDK workaround. A read-only CDP browser diagnostic did not return before its orchestration cell was stopped and produced no usable browser artifact; no diagnosis inferred. Preserve logs/failure and avoid more unbounded retries for a rejected backend candidate.

Navigation READY clocks6.74/63.38/8.35s include much more than app fixture/load clocks. Separate bounded fresh single-thread request diagnostic reached READY~1.02s, did not reproduce63s. It observed remote Roboto~688.5ms and pending remote NotoSansArabic at first READY; shutdown-aborted icon requests are not startup failures. Outlier cause unknown. ADR-012 selects font/version/license/readiness control recovery before further cache experiments; existing profiles cannot qualify full font readiness/fidelity. Physical input/presentation/soak/platform gate stays NO-GO;27/249 tasks checked, no inflated progress.

Files changed in this execution:
- `lib/src/benchmarks/benchmark_page.dart`: native/dart2js/dart2wasm compiler metadata only.
- `tool/run_web_benchmark.mjs`: opt-in bounded engine/resource/worker/thread/header audit, expected-backend rejection and late-error audit retention.
- `tool/serve_benchmark.py` (new): loopback build server with optional diagnostic COOP/COEP/no-store and server disposal.
- `tool/summarize_web_backends.py` (new): matched observed3-arm controls, complete distribution/commit validation and explicit nonqualification.
- `tool/inspect_web_startup.mjs` (new): bounded owned-browser request/failure/console/readiness diagnostic.
- `README.md`: commands/configuration and recorded limitations.
- `docs/MASTER_PLAN.md`: WB-0119 actual backend rejection and next controlled-font investigation, no new completion credit.
- `docs/ARCHITECTURE.md`: laboratory-only probe/server boundary and unadopted backend.
- `docs/DECISIONS.md`: execution04 protocol and ADR-012 measured reassessment.
- `docs/PERFORMANCE.md`: actual distributions/backend/thread/density/cold clocks/provenance/test failures and limits.
- `docs/TEST_MATRIX.md`: actual3+3/analysis,0 Wasm cases and strict diagnostic checks.
- `docs/PROJECT_STATUS.md`, `docs/RISKS.md`, `docs/HANDOFF.md`: current progress, failures, controlled-font priority and exact resume.
- `docs/DEVELOPMENT_LOG.md`: this record.
- `benchmark_results/execution-04/` (new): three raw reports/complete summary, source/binary/index/SDK provenance,12 negative fixtures, startup trace, test/control/stop/verification checkpoints. No large trace recordings.

No migration/config/package/Android/iOS command required. Manual platform/device/physical-input/long-memory/full-fidelity qualification remains pending. No background work after checkpoint.

Execution04 final checks: cached index and profile source hashes unchanged; source archive saved, syntax/diff/task counts valid. Managed collectors exit0 and owned server finally blocks complete; interrupted SDK harness confirms Chromium shutdown. Separate read-only CDP/final process-audit cells did not return and were terminated; residual read-only client state unconfirmed, no global process-absence claim. Final free capacity~3.27GiB. No further engineering execution after checkpoint.

## 2026-10-19 — Execution05 controlled fonts and rendering evidence

WB-0120 verified;28/250=11.20%. WB-0119 still IN_PROGRESS, WB-0114 NO-GO, WB-0715 production font policy remains unchecked. Fixed official unmodified Roboto3.015 regular/medium/bold and NotoSansArabic2.012 regular with OFL notices/source/archive/file/license hashes; no dependency/SDK/lockfile/platform upgrade. Four files1,676,168 bytes. Explicit once-per-engine lab registrations before UI/paragraphs; bounded asset waits, concurrent deduplication, retry unfinished faces, actionable failure, disposed/late gates, READY preparation metadata. Local manifest Roboto avoids engine's forced pre-Dart external default font; shared pubspec addition is explicit, production curation not assumed.

Actual root causes/fixes: first retry created error future before FutureBuilder attached; creation deferred into build. Chrome test environment ignores platform asset messages and forces Ahem, so moving load to setUpAll could not help; test-only supported asset bridge reads verified generated copies and enables actual custom fonts with downloaded fallbacks disabled. Ready-future async boundary later blocked a widget factory/error case; synchronous ready completion and skipping unnecessary renderer await preserve prior behavior. All initial failures/interrupted0/partial suites retained and excluded, never counted as a successful full run.

Genuine fonts exposed old warm raster mismatch BEFORE edits: at1.25×,2× tile resampling yields324 direct/266 cached threshold-dark pixels, mean channel-byte error0.7133; postmove322/265. These are antialias-sensitive counts, not missing-character counts. Narrow reported full ordered direct fallback for text-bearing scenes at nonbucket scale; immutable text flag once, no per-frame full-scene scan. Original bounds retained and strengthened to exact pixel/fallback proof. Aligned cache tests remain genuine cache proofs; matching-scale subpixel phase remains unqualified. Preparation/repair lifecycle retained; cache performance is not claimed for fallback. Independent read-only reviews found no blocking loader/ownership issue and endorsed this limited containment.

Executed116 host116 Chrome across17 fresh file processes per target, identical unchanged sources/assets; analysis clean, changed Dart format/diff clean. Four font assets/license/version/weight/cmap checks and four malformed cases PASS; paragraph stability does not prove shaping. Three matched CanvasKit Profile arms/12 rows: stage dense P95 direct33.221/33.935/33.335ms, vector27.485/26.850/25.230, layers25.675/26.495/33.959.5,638 dense visible of10K, canvas1200×542/DPR1. Interleaved layers fully fall back; bounds unchanged. First-use clocks kept; no warmup exclusion or candidate promotion. No new native Profile or required-device/input/soak qualification. Prior Wasm0 cases preserved, not rerun.

Font transfers all complete locally before first READY. Fresh external-blocked startup548.517ms, no external attempts/errors/warnings;52–55ms combined runtime read/registration in frame arms. Historical startup63s outlier causation unproven; new metrics not an isolated font-cause comparison. First runner suite stopped after direct arm because preflight socket lacked HTTPServer's TIME_WAIT reuse option; owned server was closed. Corrected helper, preserved incomplete suite and recaptured all arms. Independent audit fully recomputed2,911 frames/617 commits, checked64 source hashes/21 final compiled artifacts/19 stable engine/font/manifests, rejected18 malformed evidence cases. Actual chromium engine route hashed before capture; earlier app/bootstrap bytes overwritten, runner hashes retained, no wire digest claim. No heavy concurrent work during timings.

Exact files changed/created this execution (existing mixed work preserved):

- `.gitignore`: ignore only generated Chrome font fixture copies. `pubspec.yaml`: local font assets and engine-default Roboto declaration; packages/lockfile unchanged.
- `assets/benchmark_fonts/Roboto-Regular.ttf`, `Roboto-Medium.ttf`, `Roboto-Bold.ttf`, `NotoSansArabic-Regular.ttf`: unmodified fixed upstream fonts. `Roboto-OFL.txt`, `NotoSansArabic-OFL.txt`: original notices. `manifest.json`: versions/provenance/byte/archive/license digests.
- `lib/benchmark_main.dart`: awaited font gate, explicit themed aliases, failure/retry/disposal-safe builder. `lib/src/benchmarks/benchmark_fonts.dart`: engine-lifetime fixed loader/readiness/failure/timeouts/report. `benchmark_page.dart`: READY/run font report. `scene_renderer.dart`: readiness/explicit paragraph fonts, immutable text flag and reported nonbucket tile fallback.
- `test/benchmark_fonts_test.dart`:7 meaningful concurrent/failure/engine-retry/timeout/late/disposal/paragraph cases. `test/flutter_test_config.dart`, `test/support/font_assets_host.dart`, `test/support/font_assets_web.dart`: once-per-engine test preparation and conditional genuine-font browser asset bridge. `test/dirty_tile_repair_test.dart`, `test/recovery_cache_test.dart`: preserve original bounds, add exact fractional fallback pixels/counters; accurately label fallback.
- `tool/verify_benchmark_fonts.py`: stdlib integrity/OFL/SFNT/cmap audit,4 negative cases, optional hash-verified test fixture copies. `tool/run_test_batches.py`: audit/preflight and asset hashes. `tool/run_web_benchmark.mjs`: opt-in local font transfer/readiness audit and explicit font-failure rejection. `tool/start_web_benchmark.js`: retain font failures. `tool/inspect_web_startup.mjs`: optional external-blocked readiness diagnostic. `tool/run_font_profiles.py`: serial owned bounded builds/collectors/servers, pre-capture binaries/manifests/asset/source hashes and font controls. `tool/validate_font_profiles.py`: independent post-capture raw-distribution/control/manifest/provenance/negative validator.
- `README.md`, `docs/ARCHITECTURE.md`, `DECISIONS.md`, `DEVELOPMENT_LOG.md`, `HANDOFF.md`, `MASTER_PLAN.md`, `PERFORMANCE.md`, `PROJECT_STATUS.md`, `RISKS.md`, `TEST_MATRIX.md`: actual commands/ownership/ADR-013/limits/results/next actions; all historical reports/raw evidence preserved.
- `benchmark_results/execution-05/`: source/archive/provenance/raw frame+commit samples, audit/verification/summaries/startup, preserved initial failures/incomplete attempts and final checkpoint. Generated logs/builds/fixture copies stay ignored. No blanket stage/reset/commit; original index preserved.

For direct Chrome tests run `python3 tool/verify_benchmark_fonts.py --prepare-web-tests` first; batch runner does this automatically. No migration or Android/iOS/Windows configuration step. Manual/required device/Arabic shaping/IME/input/long-memory checks remain pending tasks. Next per ADR-012/013: exact device-phase pixel equivalence and bounded cold/stale/fragmentation/resource proof before selection-scoped static raster ranges; independent visual geometry contracts remain allowed. Current build/web is layers CanvasKit laboratory, not product release. No background engineering after final checkpoint.
