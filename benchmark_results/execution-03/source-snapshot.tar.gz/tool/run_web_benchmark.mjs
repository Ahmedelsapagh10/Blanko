// Uses the existing bundled Playwright runtime; adds no project dependency.
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { createGzip } from 'node:zlib';
import { once } from 'node:events';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
const require = createRequire(import.meta.url);
const args = process.argv.slice(2);
const option = (name, fallback) => args.includes(name) ? args[args.indexOf(name)+1] : fallback;
const modulePath = option('--playwright', process.env.PHASE01_PLAYWRIGHT || 'playwright');
const output = option('--output', 'benchmark_results/phase01/web-profile.json');
const stopAfter=Number(option('--stop-after','0'));
const traceAfter=option('--trace-after',undefined);
let resultCount=0;
const { chromium } = require(modulePath);
const executablePath=option('--executable',undefined);
const browser = await chromium.launch({ headless: true, args:args.includes('--hardware-metal') ? ['--enable-gpu','--use-angle=metal'] : [], ...(executablePath ? {executablePath} : {}) });
let timeout;
let captureTimer;
let stopTimer;
let capturePromise = Promise.resolve();
let traced = false;
const page = await browser.newPage({viewport:{width:1200,height:796},deviceScaleFactor:1});
const session = await page.context().newCDPSession(page);
const prefix = output.replace(/\.json$/, '');
async function saveTrace() {
  const done = new Promise(resolve => session.once('Tracing.tracingComplete', resolve));
  await session.send('Tracing.end');
  const event = await done;
  const zip = createGzip();
  const stream = fs.createWriteStream(prefix+'.timeline.json.gz');
  zip.pipe(stream);
  while (true) {
    const part = await session.send('IO.read',{handle:event.stream,size:65536});
    const chunk = Buffer.from(part.data,part.base64Encoded ? 'base64' : 'utf8');
    if (!zip.write(chunk)) await once(zip,'drain');
    if (part.eof) break;
  }
  await session.send('IO.close',{handle:event.stream});
  zip.end();
  await once(stream,'finish');
}
try {
  const complete = new Promise((resolve,reject) => {
    timeout=setTimeout(()=>reject(new Error('Benchmark exceeded timeout')),Number(option('--timeout','600'))*1000);
    page.on('pageerror', error => reject(error));
    page.on('console', message => {
      const line = message.text();
      const start = line.indexOf('PHASE0_');
      if (start<0) return;
      const text=line.slice(start);
      const separator=text.indexOf(' ');
      const type=text.slice(0,separator);
      let data;
      try {data=JSON.parse(text.slice(separator+1));} catch {return;}
      if(type==='PHASE0_READY') console.log(JSON.stringify({ready:data.scene,loadMs:data.loadToInteractiveMs}));
      if(type==='PHASE0_DIAGNOSTIC' && data.kind!=='pointer') console.log(JSON.stringify({diagnostic:data.kind,cycle:data.cycle,elapsedSeconds:data.elapsedSeconds,tiles:data.tiles ? {bytes:data.tiles.bytes,builds:data.tiles.builds,discarded:data.tiles.discarded} : undefined}));
      if (type==='PHASE0_RESULT') {
        console.log(JSON.stringify({scene:data.scene,workload:data.workload,stage:data.frames.stage}));
        resultCount++;
        if (stopAfter && resultCount>=stopAfter) resolve();
      }
      if (args.includes('--trace-window') && !traced && (traceAfter ? (type==='PHASE0_RESULT' && data.workload===traceAfter) : (type==='PHASE0_READY' && data.scene==='dense'))) {
        traced=true;
        capturePromise=new Promise((captureResolve,captureReject)=>{
          captureTimer=setTimeout(async()=>{
            try {
              const started=performance.now();
              await session.send('Profiler.enable');
              await session.send('Profiler.setSamplingInterval',{interval:1000});
              await session.send('Profiler.start');
              await session.send('Tracing.start',{categories:'devtools.timeline,v8,blink,cc,gpu',transferMode:'ReturnAsStream'});
              stopTimer=setTimeout(async()=>{
                try {
                  const cpu=await session.send('Profiler.stop');
                  const stopped=performance.now();
                  fs.writeFileSync(prefix+'.cpu.json.gz',await new Promise((resolve,reject)=>{
                    const gzip=createGzip(); const chunks=[];
                    gzip.on('data',c=>chunks.push(c));gzip.on('end',()=>resolve(Buffer.concat(chunks)));gzip.on('error',reject);
                    gzip.end(JSON.stringify(cpu));
                  }));
                  await saveTrace();
                  fs.writeFileSync(prefix+'.capture.json',JSON.stringify({trigger:traceAfter ? 'result:'+traceAfter : 'first dense ready',startAfterTriggerMs:7000,requestedDurationMs:3000,actualCpuCaptureWallMs:stopped-started,cpuSampleIntervalMicros:1000,categories:'devtools.timeline,v8,blink,cc,gpu'},null,2)+'\n');
                  captureResolve();
                } catch(error) {captureReject(error);}
              },3000);
            } catch(error) {captureReject(error);}
          },7000);
        });
        // A failed capture must be observed promptly rather than rejected silently.
        capturePromise.catch(reject);
      }
      if (type==='PHASE0_SUITE_DONE') resolve();
      if (type==='PHASE0_SUITE_FAILED') reject(new Error(text));
    });
  });
  const start = eval('('+fs.readFileSync(new URL('./start_web_benchmark.js',import.meta.url),'utf8')+')');
  const environment = await start(page);
  console.log('PHASE01_ENV '+JSON.stringify(environment));
  fs.writeFileSync(prefix+'.environment.json',JSON.stringify(environment,null,2)+'\n');
  if (environment.gpuCompositing!=='enabled' && !args.includes('--allow-software')) throw new Error('Hardware GPU compositing unavailable; refusing a misleading hardware comparison.');
  await complete;
  clearTimeout(timeout);
  await capturePromise;
  const report=await page.evaluate(()=>window.__phase0);
  report.environment=environment;
  if(args.includes('--memory')) {
    const beforeGc=await session.send('Runtime.getHeapUsage');
    await session.send('HeapProfiler.collectGarbage');
    const afterGc=await session.send('Runtime.getHeapUsage');
    report.finalJsHeap={beforeGc,afterGc,includesGpuMemory:false};
  }
  if(stopAfter) {report.boundedDiagnosticStopAfter=stopAfter; report.diagnosticComplete=report.runs.length===stopAfter;}
  report.collector={playwright:require(modulePath+'/package.json').version,traceWindow:args.includes('--trace-window') ? '7–10 seconds after '+(traceAfter ? traceAfter+' result' : 'first dense READY')+'; 1 ms CPU samples' : 'disabled for frame comparison',process:'fresh headless browser per suite'};
  fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
  if (args.includes('--input')) {
    const checksum=async()=>createHash('sha256').update(await page.screenshot({clip:{x:100,y:280,width:900,height:300}})).digest('hex');
    const before=await checksum();
    await page.mouse.move(600,450);
    await page.mouse.down();
    await page.mouse.move(850,480,{steps:120});
    await page.mouse.up();
    await page.waitForTimeout(700);
    const panned=await checksum();
    for(let i=0;i<24;i++) await page.mouse.wheel(0,-20);
    await page.waitForTimeout(700);
    const zoomed=await checksum();
    const diagnostics=await page.evaluate(()=>window.__phase0.diagnostics.filter(d=>d.kind==='pointer'));
    fs.writeFileSync(prefix+'.input.json',JSON.stringify({softwareInput:true,physicalInput:false,dragSteps:120,wheelEvents:24,panChangedCanvasRegion:before!==panned,zoomChangedCanvasRegion:panned!==zoomed,diagnostics},null,2)+'\n');
  }
  console.log('Saved '+output+'; complete='+report.complete);
  if((stopAfter ? !report.diagnosticComplete : !report.complete) || report.errors.length) process.exitCode=1;
} catch(error) {
  const bounded=(promise)=>Promise.race([promise,new Promise((_,reject)=>setTimeout(()=>reject(new Error('Diagnostic snapshot timed out')),3000))]);
  try {
    const partial=await bounded(page.evaluate(()=>window.__phase0));
    partial.collectorError=String(error);
    fs.writeFileSync(output,JSON.stringify(partial,null,2)+'\n');
  } catch {}
  try { await bounded(page.screenshot({path:prefix+'.failure.png'})); } catch {}
  throw error;
} finally {
  clearTimeout(timeout);clearTimeout(captureTimer);clearTimeout(stopTimer);
  await browser.close();
}
