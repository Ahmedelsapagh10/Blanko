import 'package:flutter/material.dart';

import 'src/benchmarks/benchmark_page.dart';

void main() {
  final startupClock = Stopwatch()..start();
  runApp(BenchmarkApp(startupClock: startupClock));
}

class BenchmarkApp extends StatelessWidget {
  const BenchmarkApp({super.key, this.startupClock});
  final Stopwatch? startupClock;

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Whiteboard rendering spike',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff2563eb)),
      useMaterial3: true,
    ),
    home: BenchmarkPage(startupClock: startupClock),
  );
}
